import os
import numpy as np
import matplotlib.pyplot as plt
import cv2
import eigenfaces as ef


def run_training(images, labels):

    faces_mat = np.dstack(images)

    # Compute Eigenfaces
    eigenfaces, faces_proj = ef.compute_eigenfaces(faces_mat)

    # Reshape to vectors
    mean_vecs, labels_unique, cov_mat = ef.mean_eigenvecs(faces_mat, eigenfaces, labels)

    # Save Eigenfaces
    print("Saving train data")
    np.savez("train_data", eigenfaces=eigenfaces, faces_proj=faces_proj,
             mean_vecs=mean_vecs, labels_unique=labels_unique,
             cov_mat=cov_mat)


def plot_faces(eigenfaces, faces_proj):
    fig = plt.figure()
    fig.subplots_adjust(left=0.05, bottom=0.05, right=0.95, top=0.95, wspace=0.05, hspace=0.05)
    for n in range(32):
        ax = fig.add_subplot(6, 6, n + 1)
        ax.imshow(eigenfaces[:, :, n], cmap='gray')
        # ax.set_title("Eigenface #%d" % n)
        plt.axis('off')
    fig.suptitle("First 32 eigenfaces")

    # Projection on eigenfaces
    fig = plt.figure()
    ax = fig.add_subplot(1, 1, 1)
    cax = ax.imshow(faces_proj.T, cmap='Spectral')
    ax.set_xlabel("Input Faces")
    ax.set_ylabel("Eigenfaces")
    ax.set_title("Projection of input faces on the eigen faces")
    ax.set_xticks(range(0, faces_proj.shape[0], 15))
    ax.grid(which='major', alpha=1.0)
    plt.gca().yaxis.grid(False)
    fig.colorbar(cax)
    fig.tight_layout()
    plt.show()


def load_pretrained():
    data = np.load("train_data.npz")
    plot_faces(data['eigenfaces'], data['faces_proj'])

if __name__ == "__main__":
    images, labels = ef.load_dataset(db_folder="../images/train_data_set")
    run_training(images, labels)
    load_pretrained()
