import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import eigenfaces as ef


def load_train_data(fn="train_data.npz"):
    train_data = np.load(fn)
    eigenfaces = train_data['eigenfaces']
    mean_vecs = train_data['mean_vecs']
    labels = train_data['labels_unique']
    cov_mat = train_data['cov_mat']
    return eigenfaces, mean_vecs, labels, cov_mat


def test_image(im, eigenfaces, mean_vecs, labels, cov_mat, max_dist_th=10.0):
    eigenvecs = eigenfaces.reshape((-1, eigenfaces.shape[-1]))
    mahal_dist = ef.compute_mahal_dist(im, eigenvecs, mean_vecs, cov_mat)
    class_ind, ratio_test = ef.classify(mahal_dist)
    min_dist = mahal_dist[class_ind]
    if min_dist > max_dist_th:
        result_person = None
    else:
        result_person = labels[class_ind]
    return result_person, min_dist

def test_folder(folder, eigenfaces, mean_vecs, labels, cov_mat, max_dist_th=10.0):
    images, labels_test = ef.load_dataset(folder)
    labels_pred = []
    score = []
    for ind, im in enumerate(images):
        result_person, min_dist = test_image(im, eigenfaces, mean_vecs,
                                             labels, cov_mat, max_dist_th)
        labels_pred.append(result_person)
        score.append(min_dist)
    return labels_test, labels_pred, score

def analyze_results(labels, labels_pred, score, in_db):
    df = pd.DataFrame(np.vstack((labels, labels_pred, score, in_db)).T,
                      columns=('gt', 'pred', 'score', 'in_db'))
    # Check if prediction is correct
    df['in_db'] = df['in_db'].astype(bool)
    df['correct'] = df['gt'] == df['pred']
    df.loc[~df['in_db'], 'correct'] = df.loc[~df['in_db'], 'pred'].isnull()

    # Divide to true/false samples
    df_in_db = df[df['in_db']]
    df_not_in_db = df[~df['in_db']]

    # analyze true samples
    num_samples = len(df)
    num_in_db_samples = len(df_in_db)
    num_not_in_db_samples = len(df_not_in_db)

    correct_db_classification = df_in_db['correct'].sum()
    incorrect_db_classification = num_in_db_samples - correct_db_classification

    correct_not_in_db = df_not_in_db['correct'].sum()
    incorrect_not_in_db = num_not_in_db_samples - correct_not_in_db

    print("==============================================")
    print("Total samples in DB: %d" % num_in_db_samples)
    print("  Correctly classified: %d (%.1f%%)" %
          (correct_db_classification, (correct_db_classification/float(num_in_db_samples))*100.0))
    print("  Incorrectly classified: %d (%.1f%%)" %
          (incorrect_db_classification, (incorrect_db_classification / float(num_in_db_samples)) * 100.0))

    print("\nTotal samples not in DB: %d" % num_not_in_db_samples)
    print("  Correctly classified as not in DB: %d (%.1f%%)" %
          (correct_not_in_db, (correct_not_in_db/float(num_not_in_db_samples))*100.0))
    print("  Incorrectly classified as person: %d (%.1f%%)" %
          (incorrect_not_in_db, (incorrect_not_in_db/float(num_not_in_db_samples))*100.0))
    print("==============================================")

    # Number of correct by person
    # correct_by_person = df.groupby('gt').sum()['correct']
    # print("Correct prediction by person:")
    # print(correct_by_person)

    df.to_csv("result.csv")

if __name__ == "__main__":
    eigenfaces, mean_vecs, labels, cov_mat = load_train_data()
    labels_p, labels_pred_p, score_p = test_folder("../images/positive_test_images",
                                             eigenfaces, mean_vecs, labels, cov_mat, max_dist_th=10.0)
    labels_n, labels_pred_n, score_n = test_folder("../images/negative_test_images",
                                             eigenfaces, mean_vecs, labels, cov_mat, max_dist_th=10.0)
    labels = labels_p + labels_n
    labels_pred = labels_pred_p + labels_pred_n
    score = score_p + score_n
    in_db = [True]*len(labels_p) + [False]*len(labels_n)
    analyze_results(labels, labels_pred, score, in_db)
    print("")
